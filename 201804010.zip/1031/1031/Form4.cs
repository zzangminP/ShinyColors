﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1031
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        int a = 1, b = 1, c = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(Environment.CurrentDirectory + "/엄마에게 다가가는 새끼 코끼리/" + a + ".jpg");
            pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/" + b + ".jpg");
            pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/" + c + ".jpg");
            a++;
            b++;
            c++;
            if (a > 4)
                a = 1;
            if (b > 5)
                b = 1;
            if (c > 6)
                c = 1;
        }
    }
}
