﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1031
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private int m_iposition, m_ilnc;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
            if (m_iposition == 5)
                m_ilnc = -1;
            if (m_iposition == 0)
                m_ilnc = 1;
            m_iposition = m_iposition + m_ilnc;
            hScrollBar1.Value = m_iposition;

        
        }
    }
}
