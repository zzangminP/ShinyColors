﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1031
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        public void Change1(int a)
        {

            switch (a)
            {
                case 1: pictureBox1.Image = Image.FromFile(Environment.CurrentDirectory + "/엄마에게 다가가는 새끼 코끼리/1.jpg");
                    break;
                case 2: pictureBox1.Image = Image.FromFile(Environment.CurrentDirectory + "/엄마에게 다가가는 새끼 코끼리/2.jpg");
                    break;
                case 3: pictureBox1.Image = Image.FromFile(Environment.CurrentDirectory + "/엄마에게 다가가는 새끼 코끼리/3.jpg");
                    break;
                case 4: pictureBox1.Image = Image.FromFile(Environment.CurrentDirectory + "/엄마에게 다가가는 새끼 코끼리/4.jpg");
                    break;
            }


        }
        public void Change2(int a)
        {

            switch (a)
            {
                case 1:
                    pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/1.jpg");
                    break;
                case 2:
                    pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/2.jpg");
                    break;
                case 3:
                    pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/3.jpg");
                    break;
                case 4:
                    pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/4.jpg");
                    break;
                case 5:
                    pictureBox2.Image = Image.FromFile(Environment.CurrentDirectory + "/다가오는 코끼리 두마리/5.jpg");
                    break;
            }


        }
        public void Change3(int a)
        {

            switch (a)
            {
                case 1:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/1.jpg");
                    break;
                case 2:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/2.jpg");
                    break;
                case 3:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/3.jpg");
                    break;
                case 4:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/4.jpg");
                    break;
                case 5:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/5.jpg");
                    break;
                case 6:
                    pictureBox3.Image = Image.FromFile(Environment.CurrentDirectory + "/돌아서는 오버액션토끼/6.jpg");
                    break;
            }


        }

        int pic_val1 = 1;
        int pic_val2 = 1;
        int pic_val3 = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            Change1(pic_val1);
            Change2(pic_val2);
            Change3(pic_val3);

            pic_val1++;
            pic_val2++;
            pic_val3++;
            if (pic_val1 > 4)
                pic_val1 = 1;
            if (pic_val2 > 5)
                pic_val2 = 1;
            if (pic_val3 > 6)
                pic_val3 = 1;
        }
    }
}
