<?php
  print("hello php\n");
  print "hello php\n";
  echo "hello php\n";

 ?>
