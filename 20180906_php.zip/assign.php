<?php
$x=10;
$x +=1;
print "x=".$x."<br>";

$y=10;
$y*=2;
print "y=".$y."<br>"

 ?>
