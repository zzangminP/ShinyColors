<?php
$x = 10;
$x++;
print "x=".$x."<br>";

$y = 10;
$y--;
print "y=".$y."<br>";
 ?>
