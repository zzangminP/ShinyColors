<?php
$num = 10.5;
$int_num = (int)$num;
print $int_num;
 ?>
