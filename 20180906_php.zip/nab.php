<?php
$garo = 3;
$sero = 5;
$nab = $garo*$sero;
print $nab;
 ?>
