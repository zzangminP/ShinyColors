<?php
  $a = 10;
  print $a;
  print "<br/>";
  $a++;
  print $a;
 ?>
