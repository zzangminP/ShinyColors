<?php
$r = 2;
$area = 3.14*$r*$r;
print $area;
 ?>
