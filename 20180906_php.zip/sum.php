<?php
$sum = 12+23;
print $sum;
 ?>
