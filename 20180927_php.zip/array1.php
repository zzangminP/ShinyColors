<?PHP
$num[] = 1; $num[] = 2 ; $num[] = 3 ;

print $num[0] . "<p>" . $num[1] . "<p>" . $num[2] . "<p>";

?>