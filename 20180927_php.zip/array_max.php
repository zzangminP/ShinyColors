<?PHP
  $num = array (85, 90, 75, 100, 95);

sort($num);
$max = $num[4];
  print "�ִ밪 : " . $max ;
?>