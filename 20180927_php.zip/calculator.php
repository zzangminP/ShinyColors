<?PHP
 $num1 = $_POST["op1"];
 $num2 = $_POST["op2"];
 $op = $_POST["op"];

  function calc($a, $b, $c)  {

	switch($c){ 
	case '+' : $d= $a + $b; break; 
	case '-' : $d = $a - $b; break; 
	case '*' : $d = $a * $b; break; 
	case '/' : $d = $a / b; break; 
} 
    return $d;
  }

  $result = calc($num1, $num2, $op);
  print "$num1 $op $num2 = $result ";
?>
