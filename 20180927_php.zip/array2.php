<?PHP
$name[] = "spring";   $name[] = "summner";
$name[] = "fall";        $name[] = "winter";


print $name[1] . "<p>" . $name[3] . "<p>" ;

?>