
<?PHP

function absolute($num){

if($num<0){
$num = $num * -1;
}
return $num;
}


  $result = absolute (3);
  print $result . "<br>";

  $result = absolute (-10);
  print $result;

?>
