<?PHP
 $num1 = $_POST["num"];
function calcTemp($num){
$hwa = $num * 1.8 + 32;

return $hwa;

}


  $result = calcTemp($num1);
  print "���� : $num1 --> ȭ�� :  $result ";
?>