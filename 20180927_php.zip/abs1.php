<?PHP
 $num1 = $_POST["num"];


function absolute($num){

if($num<0){
$num = $num * -1;
}
return $num;
}


  $result = absolute ($num1);
  print $result ;
?>