<?PHP
  $num = array (85, 90, 75, 100, 95);
  $sum=0;

  foreach($num as $value) 
  {
     $sum = $sum + $value;
  }

  $avg = $sum/5;
  print "���� : " . $sum . "<br> ��� : " . $avg . "<br>";
?>