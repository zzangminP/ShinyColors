<?PHP
 $num1 = $_POST["num"];
function calcFactorial($num){
if ($num == 1)
	return $num;
else
	return $num * calcFactorial($num-1);
}

  $result = calcFactorial($num1);
  print "���� : $num1 --> ���丮�� :  $result ";
?>