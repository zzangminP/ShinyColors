<?PHP
  function add($x,$y)
  {
      $sum = $x + $y;
      return $sum;
  }

  $result = add (3, 5);
  print $result . "<br>";

  $result = add (10, 20);
  print $result;

?>