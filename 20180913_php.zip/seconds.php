<?php
$tot=$_POST["hour"]*3600+$_POST["minute"]*60+$_POST["second"];
print $_POST["hour"]."�� ".$_POST["minute"]."�� ".$_POST["second"]."�� ->".$tot."��<br/>";



 ?>
