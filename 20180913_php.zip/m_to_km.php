<?php
$km=floor($_POST["m"]/1000);
$m2=$_POST["m"]%1000;

print "�Է��� m : ".$_POST["m"]."->".$km."km".$m2."m<br/>";



 ?>
