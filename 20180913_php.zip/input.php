<html>
	<head>
		<title>�� �Է� �ޱ�</title>
	</head>
	<body>
		<form name=read method=post action="output.php">
			���� : <input type=text name=num><br>
			<input type=submit value="OK">
		</form>
	</body>
</html>