function over(obj){
  obj.src="amana.png";
}
function out(obj){
  obj.src="tenka.png";
}
