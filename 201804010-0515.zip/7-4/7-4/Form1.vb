﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each i In {1, 2, 4}
            Dim cb As ComboBox = Me.Controls("GroupBox1").Controls("combobox" & i)
            With cb.Items
                .AddRange({"Solid", "dash", "dot", "dashdot", "dashdotdot"})
            End With
        Next
        For Each i In {3, 5}
            Dim cb As ComboBox = Me.Controls("GroupBox1").Controls("combobox" & i)
            With cb.Items
                .AddRange({"transparent", "solid", "horizontal", "vertical"})
            End With
        Next
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim value = ComboBox1.SelectedIndex
        LineShape1.BorderStyle = value
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim value = ComboBox2.SelectedIndex
        OvalShape1.BorderStyle = value
        Dim value2 = ComboBox3.SelectedIndex
        OvalShape1.FillStyle = value - 2
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim value1 = ComboBox4.SelectedIndex
        RectangleShape1.BorderStyle = value1 - 2
        Dim value2 = ComboBox5.SelectedIndex
        RectangleShape1.FillStyle = value2 - 2
    End Sub
End Class