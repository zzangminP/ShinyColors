﻿Public Class Form1
    Function tt()
        TextBox1.Text = DriveListBox1.Drive
        TextBox2.Text = DirListBox1.Path
        TextBox3.Text = FileListBox1.Path
        TextBox4.Text = FileListBox1.FileName
        TextBox5.Text = FileListBox1.Pattern
        Return 0
    End Function
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tt()
    End Sub
    Private Sub DriveListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DriveListBox1.SelectedIndexChanged
        DirListBox1.Path = DriveListBox1.Drive
        tt()
    End Sub
    Private Sub FileListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles FileListBox1.SelectedIndexChanged
        tt()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FileListBox1.Pattern = TextBox5.Text
        FileListBox1.Refresh()
        tt()
    End Sub
End Class
