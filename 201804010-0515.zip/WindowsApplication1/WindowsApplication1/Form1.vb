﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim filepointer = Val(OpenFileDialog1.showdialog())

        If filepointer Then
            PictureBox1.ImageLocation = OpenFileDialog1.FileName
        End If

    End Sub
End Class
