<?PHP

$num1 = array('a','b','c'); 
$num2 = array('a','b','c');
$num3 = array('b','c','a'); 
$num4 = array('a','b','d');

$num5 = $num1+$num2 ; // num1�� num2�� ������

print "$num1�� $num2�� ������ ��� : ";

foreach ($num5 as $value) 
     print "$value  ";

print "<p>";

if($num1 == $num2)     
    print "num1 == num2 <br>";

if($num1 === $num2)    
    print "num1 === num2 <br>";

if($num1 === $num3)    
    print "num1 === num3 <br>";

if($num1 != $num3)    
    print "num1 != num3 <br>";
?>